
const googleApiKey = 'YOUR_GOOGLE_CLOUD_API_KEY';
const microsoftApiKey = 'YOUR_MICROSOFT_TRANSLATOR_API_KEY';
const microsoftRegion = 'YOUR_MICROSOFT_TRANSLATOR_REGION'; // e.g., 'westus'

async function translateText() {
    const text = document.getElementById('inputText').value;
    const source = document.getElementById('sourceLang').value;
    const target = document.getElementById('targetLang').value;
    const useMicrosoft = document.getElementById('useMicrosoft').checked;

    if (useMicrosoft) {
        const url = `https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&from=${source}&to=${target}`;
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Ocp-Apim-Subscription-Key': microsoftApiKey,
                'Ocp-Apim-Subscription-Region': microsoftRegion
            },
            body: JSON.stringify([{ Text: text }])
        });
        const result = await response.json();
        document.getElementById('outputText').innerText = result[0].translations[0].text;
    } else {
        const url = `https://translation.googleapis.com/language/translate/v2?key=${googleApiKey}`;
        const data = {
            q: text,
            source: source,
            target: target,
            format: 'text'
        };
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        document.getElementById('outputText').innerText = result.data.translations[0].translatedText;
    }
}

function copyText() {
    const output = document.getElementById('outputText').innerText;
    navigator.clipboard.writeText(output);
}

function speakText() {
    const text = document.getElementById('outputText').innerText;
    const utterance = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(utterance);
}
